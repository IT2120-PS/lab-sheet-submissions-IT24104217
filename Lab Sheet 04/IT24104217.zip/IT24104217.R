##Setting Directory
setwd("C:\\Users\\it24104217\\Desktop\\IT24104217")

##Importing the data set
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

##view the file in a separate window
fix(branch_data)

##Attach the file into R. then I can call the variables by their names.
attach(branch_data)

##2. Identify the variable type and scale of measurement for each variable
str(branch_data)

##3. Obtain boxplot for sales and interpret the 
##shape of the sales distribution.

boxplot(Sales_X1,main="Box plot for sales",outline=TRUE,outpch=8,horizontal=TRUE)

#4. Calculate the five number summary and IQR for advertising variable.

summary(Advertising_X2)

IQR_advertising <- IQR(Advertising_X2)

print(IQR_advertising)


#5. Write an R function to find the outliers in a numeric vector and check for outliers
#   in years variables.

# Define the outlier detection function
find_outliers <- function(x) {
  # Calculate Q1, Q3, and IQR
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  # Calculate lower and upper bounds for outliers
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  # Identify outliers (values outside the bounds)
  outliers <- x[x < lower_bound | x > upper_bound]
  
  # Return the outliers
  return(outliers)
}


  outliers_years <- find_outliers(branch_data$Years_X3)
  
  # Display the outliers
  print(outliers_years)
 


